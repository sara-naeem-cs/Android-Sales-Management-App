package com.b07.controller.exceptions;

public class ItemNotFoundException extends Exception {

  /**
   * Serial ID for Item Not Found Exception.
   */
  private static final long serialVersionUID = 4664498396856300817L;

}
