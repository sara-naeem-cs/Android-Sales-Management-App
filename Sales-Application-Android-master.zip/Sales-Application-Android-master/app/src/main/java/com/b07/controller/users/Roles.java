package com.b07.controller.users;

public enum Roles {
  ADMIN, EMPLOYEE, CUSTOMER;
}
