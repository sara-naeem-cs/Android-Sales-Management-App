package com.b07.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.example.view.R;

public class NewAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);
    }
}
