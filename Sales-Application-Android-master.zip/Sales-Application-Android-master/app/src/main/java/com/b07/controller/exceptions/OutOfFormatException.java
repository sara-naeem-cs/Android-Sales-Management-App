package com.b07.controller.exceptions;

public class OutOfFormatException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -3434061213007270166L;

}
