package com.b07.controller.exceptions;

public class NotInDatabaseException extends Exception {

  /**
   * Serial ID for Not In Database Exception.
   */
  private static final long serialVersionUID = -3103619262631454208L;


}
